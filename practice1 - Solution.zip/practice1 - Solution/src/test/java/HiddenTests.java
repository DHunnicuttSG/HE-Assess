import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.example.UtilFunctions.*;
import static org.example.UtilFunctions.oddOrEven;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class HiddenTests {

    @Test
    @DisplayName("Test multiples of 3 widgets")
    public void testTimes3Widgets() {
        assertEquals(3, calcWidgetCost(9));
        assertEquals(5, calcWidgetCost(15));
    }

    @Test
    @DisplayName("Test Widget of 0 or negative")
    public void testNegativeWidgets() {
        assertEquals(0, calcWidgetCost(0));
        assertEquals(0, calcWidgetCost(-8));
    }

    @Test
    @DisplayName("Test zero and negative numbers")
    public void testZeroAndNegativeNums() {
        assertEquals(11, addDigitsOfNum(-56));
        assertEquals(0, addDigitsOfNum(0));
    }

    @Test
    @DisplayName("Test removing duplicates from array")
    public void testRemoveDuplicatesFromArray() {
        int[] myArray = {1,1,1,2,2,2,2,3,3,3,3,3,4,4};
        assertEquals("My Array: [1, 2, 3, 4]", removeDuplicatesFromArray(myArray));

        int[] array2 = {-1,-1,-56,0,0,0,-21,-21,3,3,3 };
        assertEquals("My Array: [-1, 0, 3, -21, -56]", removeDuplicatesFromArray(array2));
    }

    @Test
    @DisplayName("Test if number is odd or even")
    public void testOddOrEven() {
        assertEquals("The number 5 is: Odd", oddOrEven(5));
        assertEquals("The number 57 is: Odd", oddOrEven(57));
        assertEquals("The number 2 is: Even", oddOrEven(2));
        assertEquals("The number 222 is: Even", oddOrEven(222));
    }
}
