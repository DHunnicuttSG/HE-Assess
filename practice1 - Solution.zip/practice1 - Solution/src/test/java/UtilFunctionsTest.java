import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.example.UtilFunctions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class UtilFunctionsTest {

    @Test
    @DisplayName("Testing Widget calculations")
    public void testWidgets() {
        assertEquals(1.65, calcWidgetCost(4));
        assertEquals(5.3, calcWidgetCost(14));
    }

    @Test
    @DisplayName("Test add digits function")
    public void testAddDigits() {
        assertEquals(7, addDigitsOfNum(16));
        assertEquals(27, addDigitsOfNum(999));
    }

}
