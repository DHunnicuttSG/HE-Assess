package org.example;

import static org.example.UtilFunctions.*;

public class Main {
    public static void main(String[] args) {
        System.out.println(calcWidgetCost(14));

        System.out.println(addDigitsOfNum(1234));

        int[] myArray = {1,1,1,2,2,2,3,3,3,4,5,6,7,7,8};
        System.out.println(removeDuplicatesFromArray(myArray));

        System.out.println(oddOrEven(5));
    }
}