package org.example;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class UtilFunctions {

    /*
    Create a method that will return the cost of a number of widgets
    Widgets sell for $.65 each, but you can get 3 for $1.00.
    for example 6 widgets cost $2.00, 7 widgets cost 2.65
    method should return zero if zero or negative numbers passed to method
     */
    public static double calcWidgetCost(int numWidgets) {
        if (numWidgets <= 0) {
            return 0.0;
        } else {
            return (numWidgets / 3) + (numWidgets % 3 * .65 );
        }
    }

    /*
    Write a method that will add the digits of a number passed to it.
    for example num = 987 return value is 24 (9 + 8 + 7)
    method should work with negative numbers giving a positive result
     */
    public static int addDigitsOfNum(int num) {
        int result = 0;
        while (num != 0){
            int grab = num % 10;  //grab number on the right
            num /= 10; //remove the last digit
            result += grab; // add grab to num
        }
        return Math.abs(result);
    }

    /*
    Write a method that will remove all the duplicates from an array
    and return the array in the form of a String.
    String should be formatted as:  My Array: [1, 2, 3, ...]
     */
    public static String removeDuplicatesFromArray(int[] intArray){
        Set<Integer> mySet = new HashSet();
        for (int item: intArray) {
            mySet.add(item);
        }

        int[] newArr = new int[mySet.size()];
        int i = 0;
        for(int item : mySet) {
            newArr[i++] = item;
        }
        return "My Array: " + Arrays.toString(newArr);
    }

    /*
    Write a method that will determine if a number is odd or even
    output should be:  "The number <num> is: Even" or "The number <num> is: Odd"

     */
    public static String oddOrEven(int num) {
        String result = "";
        if (num % 2 == 0) {
            result = "The number " + num + " is: Even";
        } else {
            result = "The number " + num + " is: Odd";
        }
        return result;
    }
}
